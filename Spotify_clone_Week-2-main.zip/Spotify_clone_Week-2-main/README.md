# Spotify_clone_Week-2
Edunet Foundation Full-stack web development Internship Project-3 Week-2
